import { useState } from "react";
import "./App.css";
import ChatbotButton from "./chatbot/ChatbotButton";
import ChatWindow from "./chatbot/ChatWindow";

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <>
      <ChatbotButton
        isOpen={isChatOpen}
        onClick={() => setIsChatOpen(!isChatOpen)}
      />
      <ChatWindow isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </>
  );
}

export default App;
